package PR2.TUT8.lms;

import PR2.TUT8.Course.Course;
import PR2.TUT8.Person.Student;

import java.util.HashMap;

public class LearningManagementSystem {
    HashMap<Integer, Student> students = new HashMap<>();
    HashMap<Integer, Course> courses = new HashMap<>();

}
