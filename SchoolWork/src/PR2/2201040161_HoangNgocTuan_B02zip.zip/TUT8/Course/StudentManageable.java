package PR2.TUT8.Course;

import PR2.TUT8.Person.Student;

public interface StudentManageable {
    void addStudent(Student a);
    void removeStudent(Student a);
    void getEnrolledStudent();
}
